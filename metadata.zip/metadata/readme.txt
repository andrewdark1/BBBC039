Metadata files

readme.txt
    This file

filenames_and_plates.csv
    Names of mask files with the plate number in BBBC022.
    These plate numbers are useful to find the original images in BBBC022
    and use the other Cell Painting channels.

segmentation_cp3.cppipe
    Baseline segmentation pipeline using CellProfiler.

test.txt
    List of images held out for final tests.

training.txt
    List of images used for training.

validation.txt
    List of images used for validation and development.
